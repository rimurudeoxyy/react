import React, { useEffect, useState } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { Plane } from 'lucide-react';

const AnimatedPlane: React.FC = () => {
  const { scrollYProgress } = useScroll();
  const [isVisible, setIsVisible] = useState(false);

  const x = useTransform(scrollYProgress, [0, 1], [-200, window.innerWidth + 200]);
  const y = useTransform(scrollYProgress, [0, 0.3, 0.7, 1], [100, 50, -50, -100]);
  const rotate = useTransform(scrollYProgress, [0, 1], [0, 360]);

  useEffect(() => {
    const unsubscribe = scrollYProgress.onChange((value) => {
      setIsVisible(value > 0.1 && value < 0.9);
    });

    return unsubscribe;
  }, [scrollYProgress]);

  if (!isVisible) return null;

  return (
    <motion.div
      className="fixed top-1/2 left-0 z-40 pointer-events-none"
      style={{ x, y }}
      initial={{ opacity: 0, scale: 0 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0 }}
    >
      <motion.div
        style={{ rotate }}
        className="relative"
      >
        <Plane className="w-12 h-12 text-cyan-400 drop-shadow-lg" />
        <motion.div
          className="absolute inset-0 bg-cyan-400/20 rounded-full blur-xl"
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.5, 0.8, 0.5],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
        {/* Vapor trail */}
        <motion.div
          className="absolute top-1/2 -left-20 h-0.5 w-16 bg-gradient-to-r from-cyan-400/60 to-transparent"
          animate={{
            opacity: [0.3, 0.6, 0.3],
          }}
          transition={{
            duration: 1.5,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      </motion.div>
    </motion.div>
  );
};

export default AnimatedPlane;